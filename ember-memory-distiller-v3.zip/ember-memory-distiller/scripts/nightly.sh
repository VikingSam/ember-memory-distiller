#!/bin/sh
# Extract this package to /home/ubuntu/ember-memory-distiller (outside memory/).
set -eu
umask 077
PACKAGE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$PACKAGE_DIR"
export PYTHONDONTWRITEBYTECODE=1
export EMBER_OPENCLAW_CONFIG="${EMBER_OPENCLAW_CONFIG:-/home/ubuntu/.openclaw-ember/openclaw.json}"
exec /usr/bin/python3 -B -m ember_memory.distiller \
  --root /home/ubuntu/ember --config "$PACKAGE_DIR/config.json" "$@"
