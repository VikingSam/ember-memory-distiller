"""JSON stdin/stdout adapter; reads an existing OpenClaw provider at runtime."""
import json
import os
from pathlib import Path
import sys
import urllib.error
import urllib.request


def run():
    request = json.load(sys.stdin)
    config_path = Path(os.environ.get('EMBER_OPENCLAW_CONFIG', '~/.openclaw-ember/openclaw.json')).expanduser()
    config = json.loads(config_path.read_text())
    provider = config.get('models', {}).get('providers', {}).get('deepseek', {})
    key = provider.get('apiKey')
    # Support a literal key, ${ENV_NAME}, or OpenClaw's environment SecretRef.
    if isinstance(key, dict) and key.get('source') == 'env':
        key = os.environ.get(key.get('id', ''))
    if isinstance(key, str) and key.startswith('${') and key.endswith('}'):
        key = os.environ.get(key[2:-1])
    if not isinstance(key, str) or not key:
        raise ValueError('DeepSeek API key unavailable in the configured provider; no files changed')
    base = provider.get('baseUrl')
    if not isinstance(base, str) or not base.startswith('https://'):
        raise ValueError('An HTTPS DeepSeek baseUrl is required in the existing configuration')
    payload = {
        'model': 'deepseek-v4-pro',
        'messages': [
            {'role': 'system', 'content': request['instruction']},
            {'role': 'user', 'content': json.dumps({'entities': request['entities'], 'sources': request['sources']})},
        ],
        'response_format': {'type': 'json_object'},
        'max_tokens': 8192,
    }
    req = urllib.request.Request(base.rstrip('/') + '/chat/completions',
                                 json.dumps(payload).encode(),
                                 {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key})
    # Refuse redirects so a misconfigured endpoint cannot forward credentials.
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    opener = urllib.request.build_opener(NoRedirect())
    with opener.open(req, timeout=150) as response:
        data = json.load(response)
    choice = data['choices'][0]
    if choice.get('finish_reason') != 'stop':
        raise ValueError('DeepSeek did not return a complete extraction')
    parsed = json.loads(choice['message']['content'])
    print(json.dumps(parsed))


if __name__ == '__main__':
    try:
        run()
    except Exception:
        # Never echo HTTP bodies, provider configuration, credentials, or input.
        print('DeepSeek extraction failed; check provider configuration and availability locally.', file=sys.stderr)
        sys.exit(1)
