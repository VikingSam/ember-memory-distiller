import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from ember_memory.distiller import START, END, build, adopt, flood_parts, redact, validate_items
from ember_memory.storage import Plan, restore, safe_path


class DistillerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.config = {'timezone': 'America/Chicago', 'entity_template': 'bank/templates/entity.md'}
        self.put('bank/templates/entity.md', '# {name}\n' + START + '\n' + END + '\n')
        self.put('CORE.md', '# Identity\n\nStay curious.\n')
        self.put('memory/2026-09-20.md', 'Morgan prefers short updates. Atlas is the new project.\n')
        self.item = {'entity': 'morgan', 'kind': 'preference', 'headline': 'Short updates feel better.', 'detail': 'Morgan prefers concise updates.', 'related': ['atlas'], 'source': 'memory/2026-09-20.md', 'quote': 'Morgan prefers short updates.'}
        self.items = self.root / 'items.json'
        self.put('items.json', json.dumps({'items': [self.item]}))

    def tearDown(self):
        self.temp.cleanup()

    def put(self, rel, text):
        path = self.root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)

    def snapshot(self):
        return {str(p.relative_to(self.root)): p.read_bytes() for p in self.root.rglob('*') if p.is_file()}

    def build(self):
        return build(self.root, '2026-09-20', self.config, self.items)[0]

    def test_linking_and_idempotence(self):
        plan = self.build()
        self.assertIn('[[bank/entities/atlas]]', plan.after['bank/entities/morgan.md'].decode())
        self.assertIn('[[bank/entities/morgan]]', plan.after['bank/entities/atlas.md'].decode())
        plan.commit()
        before = self.snapshot()
        self.assertFalse(self.build().changes())
        self.assertEqual(before, self.snapshot())

    def test_dry_run_is_zero_write(self):
        self.put('config.json', json.dumps(self.config))
        before = self.snapshot()
        result = subprocess.run([sys.executable, '-m', 'ember_memory.distiller', '--root', str(self.root), '--config', str(self.root / 'config.json'), '--items', str(self.items), '--date', '2026-09-20', '--dry-run'], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('+++ bank/entities/', result.stdout)
        self.assertEqual(before, self.snapshot())

    def test_caps_demote_without_losing_content(self):
        core = ''.join(f'Paragraph {i}: ' + 'x' * 500 + '\n\n' for i in range(25))
        self.put('CORE.md', core)
        lines = [f'- Earlier fact {i}: ' + 'y' * 160 for i in range(30)]
        self.put('bank/entities/old.md', '# old\n' + START + '\n' + '\n'.join(lines) + '\n' + END + '\n')
        plan = self.build()
        self.assertLessEqual(len(plan.after['CORE.md'].decode()), 8000)
        flood = flood_parts(plan.after['bank/entities/old.md'].decode())[1]
        self.assertLessEqual(len(''.join(x + '\n' for x in flood)), 2500)
        all_text = '\n'.join(x.decode() for x in plan.after.values())
        for line in lines:
            self.assertIn(line, all_text)
        for paragraph in core.split('\n\n'):
            self.assertIn(paragraph, all_text)

    def test_restore_and_archive_new_files(self):
        before = self.snapshot()
        ident = self.build().commit()
        restore(self.root, ident)
        for rel, content in before.items():
            self.assertEqual((self.root / rel).read_bytes(), content)
        self.assertFalse((self.root / 'bank/entities/morgan.md').exists())
        self.assertTrue(list(self.root.glob('.ember-distiller/restore-archives/**/*morgan.md')))

    def test_restore_rejects_later_edits(self):
        ident = self.build().commit()
        self.put('bank/entities/morgan.md', 'newer edit')
        with self.assertRaisesRegex(RuntimeError, 'later edits'):
            restore(self.root, ident)

    def test_concurrent_edit_rejected(self):
        plan = self.build()
        self.put('memory/2026-09-20.md', 'changed')
        with self.assertRaisesRegex(RuntimeError, 'Concurrent'):
            plan.commit()
        self.assertFalse((self.root / 'bank/entities/morgan.md').exists())

    def test_failed_provider_changes_nothing(self):
        before = self.snapshot()
        config = dict(self.config, extractor_command=[sys.executable, '-c', 'import sys; sys.exit(1)'])
        with self.assertRaisesRegex(RuntimeError, 'Extractor failed'):
            build(self.root, '2026-09-20', config)
        self.assertEqual(before, self.snapshot())

    def test_bad_evidence_and_path_rejected(self):
        for key, value in [('quote', 'Invented quote'), ('entity', '../escape'), ('headline', 'first\nsecond')]:
            item = dict(self.item, **{key: value})
            with self.assertRaises(ValueError):
                validate_items({'items': [item]}, {'memory/2026-09-20.md': 'Morgan prefers short updates.'})

    def test_secret_filter(self):
        text = 'Hello\napi_key=private-value\n-----BEGIN RSA PRIVATE KEY-----\nabc123\n-----END RSA PRIVATE KEY-----\nBye\n'
        safe = redact(text)
        self.assertNotIn('private-value', safe)
        self.assertNotIn('abc123', safe)
        self.assertIn('Bye', safe)

    def test_legacy_is_not_silently_rewritten(self):
        self.put('bank/entities/morgan.md', '# Morgan\nPrivate legacy context.\n')
        before = self.snapshot()
        with self.assertRaisesRegex(ValueError, 'adopt'):
            self.build()
        self.assertEqual(before, self.snapshot())
        plan = adopt(self.root, self.config, '2026-09-20')
        self.assertEqual(plan.after['memory/distilled/2026-09-20/morgan-legacy.md'].decode(), '# Morgan\nPrivate legacy context.\n')

    def test_symlink_escape_rejected(self):
        (self.root / 'escape').symlink_to('/private/tmp')
        with self.assertRaises(ValueError):
            safe_path(self.root, 'escape/test')

    def test_empty_day_not_marked_complete(self):
        with self.assertRaisesRegex(ValueError, 'No dated sources'):
            build(self.root, '2026-01-01', self.config, self.items)


if __name__ == '__main__':
    unittest.main()
