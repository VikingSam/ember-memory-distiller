import json
from unittest.mock import patch
import unittest
from tests import test_distiller as base
from ember_memory.distiller import adopt, build, flood_parts, START, END, plain
from ember_memory.storage import Plan, restore


class EdgeTests(unittest.TestCase):
    setUp = base.DistillerTests.setUp
    tearDown = base.DistillerTests.tearDown
    put = base.DistillerTests.put
    build = base.DistillerTests.build
    def test_project_routing(self):
        item = dict(self.item, entity='atlas', kind='project', target_page='bank/projects/atlas.md', related=['morgan'])
        self.items.write_text(json.dumps({'items':[item]}))
        plan = self.build()
        self.assertIn('bank/projects/atlas.md', plan.after)
        self.assertIn('[[bank/projects/atlas]]', plan.after['bank/entities/morgan.md'].decode())

    def test_native_flood_migration_keeps_feeling_and_archives_full_original(self):
        original = '# Person\n\n## The flood\n\nFeeling: relieved.\n\n- Prefers short updates\n  with context.\n\n---\n\n## Detail\nLong-form record.\n'
        self.put('bank/entities/morgan.md', original)
        plan = adopt(self.root, self.config, '2026-09-20')
        text = plan.after['bank/entities/morgan.md'].decode()
        self.assertIn('Feeling: relieved.', text)
        self.assertIn('with context.', text)
        self.assertNotIn('Long-form record.', text)
        self.assertEqual(plan.after['memory/distilled/2026-09-20/morgan-legacy.md'].decode(), original)

    def test_recent_reference_survives_eviction(self):
        lines = [f'- fact {i} ' + 'x'*180 for i in range(20)]
        self.put('bank/entities/old.md', START+'\n'+'\n'.join(lines)+'\n'+END)
        from ember_memory.distiller import hashed
        self.put('.ember-distiller/state.json', json.dumps({'days':{},'seen':{},'references':{hashed(lines[0]):'2026-09-20'}}))
        plan = self.build()
        live = plan.after['bank/entities/old.md'].decode()
        self.assertIn(lines[0], live)
        self.assertNotIn(lines[1], live)

    def test_interrupted_transaction_restores_and_unblocks(self):
        import ember_memory.storage as storage
        real = storage.atomic
        count = 0
        def failing(path, data):
            nonlocal count
            if '.ember-distiller/backups/' not in str(path):
                count += 1
                if count == 2:
                    raise OSError('simulated interruption')
            return real(path, data)
        with patch.object(storage, 'atomic', side_effect=failing):
            with self.assertRaises(OSError):
                self.build().commit()
        with self.assertRaisesRegex(RuntimeError, 'Incomplete transaction'):
            self.build()
        manifest = next(self.root.glob('.ember-distiller/backups/*/manifest.json'))
        restore(self.root, manifest.parent.name)
        self.assertTrue(self.build().changes())

    def test_same_evidence_paraphrase_is_deduplicated(self):
        self.items.write_text(json.dumps({'items':[self.item, dict(self.item, headline='Keep updates concise.')]}))
        plan = self.build()
        self.assertEqual(plan.after['memory/distilled/2026-09-20/morgan.md'].decode().count('## memory-'), 1)

    def test_model_markup_is_escaped(self):
        self.assertEqual(plain('[[fake]] <script>'), r'\[\[fake\]\] &lt;script&gt;')
