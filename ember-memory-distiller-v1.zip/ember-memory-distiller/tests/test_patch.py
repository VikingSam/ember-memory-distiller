import json
from pathlib import Path
import sqlite3
import subprocess
import tempfile
import unittest
from scripts.patch_openclaw import OLD, NEW, TARGET, patch_plan, revert_latest


class PatchTests(unittest.TestCase):
    def test_original_and_patched_function_with_real_sqlite(self):
        # Execute the exact JS function with a tiny query-builder bridge. Python's
        # SQLite enforces the actual 999-variable limit, not a guessed mock limit.
        db = sqlite3.connect(':memory:')
        db.setlimit(sqlite3.SQLITE_LIMIT_VARIABLE_NUMBER, 999)
        db.execute('create table memory_index_chunks(id text primary key)')
        db.executemany('insert into memory_index_chunks values (?)', ((str(i),) for i in range(18918)))
        shim = '''
const batches = [];
function getNodeSqliteKysely() {
 const q = { selectFrom(){return q;}, leftJoin(){return q;}, select(){return q;},
 where(a,b,ids){q.ids=ids; return q;} }; return q;
}
function executeSqliteQuerySync(db,q) {
 batches.push(q.ids); return {rows:q.ids.map(id=>({id,importance:null,triggers:null,project_key:null}))};
}
'''
        for source, should_fail in [(OLD, True), (NEW, False)]:
            code = shim + source + '\nreadMemoryRecallMetadata(null, Array.from({length:18918},(_,i)=>String(i))); console.log(JSON.stringify(batches));'
            result = subprocess.run(['node', '-e', code], capture_output=True, text=True, check=True)
            batches = json.loads(result.stdout)
            found = []
            try:
                for batch in batches:
                    found.extend(db.execute('select id from memory_index_chunks where id in (' + ','.join('?' for _ in batch) + ')', batch).fetchall())
            except sqlite3.OperationalError as exc:
                self.assertTrue(should_fail)
                self.assertIn('too many SQL variables', str(exc))
            else:
                self.assertFalse(should_fail)
                self.assertEqual(len(found), 18918)
                self.assertLessEqual(max(map(len, batches)), 400)
        db.close()

    def test_patch_reinstall_idempotence_and_drift(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'dist').mkdir()
            (root / 'package.json').write_text(json.dumps({'name':'openclaw','version':'2026.8.1'}))
            code = root / TARGET
            code.write_text(OLD)
            patch_plan(root).commit()
            self.assertEqual(code.read_text(), NEW)
            self.assertFalse(patch_plan(root).changes())
            revert_latest(root)
            self.assertEqual(code.read_text(), OLD)
            patch_plan(root).commit()
            code.write_text(OLD)  # simulated npm reinstall
            self.assertTrue(patch_plan(root).changes())
            code.write_text('unknown code')
            with self.assertRaises(ValueError):
                patch_plan(root)
