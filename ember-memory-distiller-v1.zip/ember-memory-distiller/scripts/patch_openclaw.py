#!/usr/bin/env python3
"""Version-scoped, backed-up patch for a confirmed unbounded memory metadata read.

This does not assert that this read is the cause of Ember's indexing failure.
Unknown installed code is rejected instead of guessed at.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from ember_memory.storage import Plan, locked, restore

OLD = '''function readMemoryRecallMetadata(db, ids) {
\tif (ids.length === 0) return /* @__PURE__ */ new Map();
\tconst query = getNodeSqliteKysely(db).selectFrom("memory_index_chunks as chunk").leftJoin("memory_index_chunk_recall_metadata as metadata", "metadata.chunk_id", "chunk.id").select([
\t\t"chunk.id as id",
\t\t"metadata.importance as importance",
\t\t"metadata.triggers as triggers",
\t\t"metadata.project_key as project_key"
\t]).where("chunk.id", "in", [...ids]);
\treturn new Map(executeSqliteQuerySync(db, query).rows.map((row) => [row.id, row]));
}'''
NEW = '''function readMemoryRecallMetadata(db, ids) {
\t// ember-memory: bounded-recall-metadata-v1 (<=400 bindings, including SQLite 999)
\tconst out = new Map();
\tconst unique = [...new Set(ids)];
\tfor (let start = 0; start < unique.length; start += 400) {
\t\tconst batch = unique.slice(start, start + 400);
\t\tconst query = getNodeSqliteKysely(db).selectFrom("memory_index_chunks as chunk").leftJoin("memory_index_chunk_recall_metadata as metadata", "metadata.chunk_id", "chunk.id").select([
\t\t\t"chunk.id as id",
\t\t\t"metadata.importance as importance",
\t\t\t"metadata.triggers as triggers",
\t\t\t"metadata.project_key as project_key"
\t\t]).where("chunk.id", "in", batch);
\t\tfor (const row of executeSqliteQuerySync(db, query).rows) out.set(row.id, row);
\t}
\treturn out;
}'''


TARGET = 'dist/engine-storage-MMPynmDa.js'


def patch_plan(root):
    plan = Plan(root)
    package = json.loads(plan.read('package.json'))
    if package.get('name') != 'openclaw' or package.get('version') != '2026.8.1':
        raise ValueError('Only OpenClaw 2026.8.1 is supported; inspect a new version before patching')
    matches = []
    for path in [root / TARGET]:
        rel = str(path.relative_to(root))
        text = plan.read(rel)
        if OLD in text:
            if text.count(OLD) != 1:
                raise ValueError('Ambiguous patch target')
            plan.write(rel, text.replace(OLD, NEW))
            matches.append(rel)
        elif NEW in text:
            matches.append(rel)
    if not matches:
        raise ValueError('Expected function not found; no patch applied. Send sanitized diagnostic callsites.')
    return plan


def revert_latest(root):
    candidates = []
    for path in root.glob('.ember-distiller/backups/*/manifest.json'):
        manifest = json.loads(path.read_text())
        if set(manifest['files']) == {TARGET} and manifest['status'] in ('prepared', 'committed'):
            candidates.append(path)
    if not candidates:
        raise ValueError('No active patch backup found; nothing reverted')
    latest = max(candidates, key=lambda p: p.stat().st_mtime_ns)
    restore(root, latest.parent.name)
    return latest.parent.name


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--package-dir', type=Path, required=True)
    p.add_argument('--dry-run', action='store_true')
    p.add_argument('--restore')
    p.add_argument('--revert', action='store_true', help='Restore the most recent active backup for the exact patch target')
    args = p.parse_args()
    root = args.package_dir.resolve()
    with locked(root):
        if args.restore or args.revert:
            if args.dry_run:
                raise ValueError('Restore does not support dry-run')
            if args.revert:
                print(json.dumps({'reverted_backup': revert_latest(root)}))
            else:
                restore(root, args.restore)
            return
        plan = patch_plan(root)
        if args.dry_run:
            print(json.dumps({'changed_files': list(plan.changes()), 'patch': 'bounded recall metadata read; indexer cause unconfirmed'}))
        else:
            backup = plan.commit()
            print(json.dumps({'backup_id': backup, 'changed_files': list(plan.changes()), 'revert': f'python3 -B scripts/patch_openclaw.py --package-dir {root} --revert'}))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, RuntimeError) as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
